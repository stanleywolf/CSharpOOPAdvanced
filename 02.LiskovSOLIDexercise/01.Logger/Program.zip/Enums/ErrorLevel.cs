﻿using System;
using System.Collections.Generic;
using System.Text;

public enum ErrorLevel
{
    INFO,WARNING,ERROR,CRITICAL,FATAL
}