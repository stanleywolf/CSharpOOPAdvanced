﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var nums = int.Parse(Console.ReadLine());
        Box<string> box = new Box<string>();

        for (int i = 0; i < nums; i++)
        {
            box = new Box<string>(Console.ReadLine());
            Console.WriteLine(box);
        }
    }
}