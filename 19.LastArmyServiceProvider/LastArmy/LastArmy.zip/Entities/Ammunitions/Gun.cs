﻿public class Gun : Ammunition
{
    private const double weight = 1.4;
    public override double Weight => weight;
    
}
