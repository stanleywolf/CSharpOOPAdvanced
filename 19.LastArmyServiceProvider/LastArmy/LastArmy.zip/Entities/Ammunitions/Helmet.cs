﻿public class Helmet : Ammunition
{
    private const double weight = 2.3;
    public override double Weight => weight;
}
  
