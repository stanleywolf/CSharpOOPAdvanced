﻿public class AutomaticMachine : Ammunition
{
    private const double weight = 6.3;
    public override double Weight => weight;
    
}