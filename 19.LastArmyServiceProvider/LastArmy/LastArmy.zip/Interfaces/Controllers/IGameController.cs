﻿public interface IGameController
{
    void GiveInputToGameController(string input);

    string RequestResult();
}
