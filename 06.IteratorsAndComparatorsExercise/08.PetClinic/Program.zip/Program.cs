﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var engine = new Engine();
        engine.Run();
    }
}