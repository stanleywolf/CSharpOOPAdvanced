﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var arr = ArrayCreator.Create(4, "Gosho");

    }
}