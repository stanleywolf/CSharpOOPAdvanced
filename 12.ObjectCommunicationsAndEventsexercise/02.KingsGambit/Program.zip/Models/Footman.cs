﻿using System;
using System.Collections.Generic;
using System.Text;

public class Footman:Subordinate
{
    public Footman(string name) : base(name, "panicking")
    {
    }
}
