﻿using System;
using System.Collections.Generic;
using System.Text;

public class PartTimeEmployee:Employee
    {
        public PartTimeEmployee(string name) : base(name, 20)
        {
        }
    }
  
  