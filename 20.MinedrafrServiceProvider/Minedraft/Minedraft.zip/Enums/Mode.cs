﻿public enum Mode
{
    Energy = 20,
    Half = 50,
    Full = 100

}
