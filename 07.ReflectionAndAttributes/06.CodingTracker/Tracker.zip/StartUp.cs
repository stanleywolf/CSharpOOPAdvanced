﻿using System;

[SoftUni("Stancho")]
class StartUp
{
    [SoftUni("Nikola")]
    public static void Main(string[] args)
    {
       Tracker.PrintMethodsByAuthor();
    }
}