﻿using System;
using System.Collections.Generic;
using System.Text;

public enum GemClarity
{
    Chipped = 1,
    Regular = 2,
    Perfect = 5,
    Flawless = 10
}
